import os
os.environ['DJANGO_SETTINGS_MODULE'] = 'admin.settings'

import django
django.setup()

import django.http

import requests
import request
import pytest
import json

from test.us_tests import TEST_USR

from services.user_services import UserServices

payload={}



def test_create_user_groups():
    if request.method =='POST':
        user_obj=UserServices()
        response=user_obj.create_user_groups(payload)
    try:
        assert response["status"] == "success"
    except AssertionError:
        assert "user name abc_se is already present" not in response["msg"]




def test_update_user_groups():
    pass


# @pytest.mark.skip(reason="not required now")
# def test_create_nested_groups():
#     user_obj=UserServices()
#     resp1=user_obj.create_user_groups(payload=TEST_USR)
#     print(resp1)
#     assert resp1["status"]=="Failure"


def test_process_user_groups_request():
    pass
     # request_factory=RequestFactory()
     # request = request_factory.get('/api/users')


def test_process_user_roles_request():
    pass



def test_delete_user_role():
    pass




def test_delete_user_from_role():
    pass


def test_update_user_roles():
    pass



def test_create_user_roles():
    pass



def test_get_user_roles():
    pass




def test_get_user_role_id():
    pass





def test_delete_user_group():
    pass


def test_process_user_request():
    pass


def test_update_user():
    pass


def test_delete_user():
    pass


def test_get_users_list():
    pass



def test_create_users():
    pass


def test_process_users_linking_request():
    pass




def test_delete_user_user_group_link():
    pass




def test_link_users_usergroups():
    pass


def test_process_user_solutions():
    pass

def test_process_users_linking_roles_request():
    pass





def test_link_users_userroles():
    pass














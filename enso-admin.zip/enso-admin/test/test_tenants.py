import os, django
import pytest

import requests

from services.tenants import tenants_active
import json
os.environ['DJANGO_SETTINGS_MODULE'] = 'admin.settings'
django.setup()
from django.contrib.sessions.middleware import SessionMiddleware
from django.test import RequestFactory

@pytest.mark.run(requests)
def test_tenants_active():
    request_factory = RequestFactory()
    middleware = SessionMiddleware()
    request = request_factory.post('/api/activeTenant',
        json.dumps({'solution_id': 'aranger1_5f2a66b5-382a-4a37-8161-01a7491a06a7'}),
                                content_type='application/json')
    middleware.process_request(request)
    response = tenants_active(request)
    assert response is not None
    assert response.status_code == 200

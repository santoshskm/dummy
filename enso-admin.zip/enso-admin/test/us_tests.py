TEST_USR_NAME = "abc_se"
TEST_USR = {"user_name": TEST_USR_NAME, "user_type":["admin","se","bu","sv"] , "id":"4de0b8d9-f854-4a87-9e0c-039f24642e3c","status":"success","user_group_id":""}
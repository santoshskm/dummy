import os
import pytest
import django
from config_vars import SERVICE_NAME
from uuid import uuid4
from xpms_common import trace

os.environ['DJANGO_SETTINGS_MODULE'] = 'admin.settings'
django.setup()
from services.case_queue import fetch_temp_soln_id_from_case_queue, fetch_agent_list, \
    validate_payload, request_data_validation, update_data_dict,get_doc_case_variable, insert_variables, \
    insert_queue, update_queue, prepare_returning_data_json, delete_queue,\
    get_queue_details, get_default_doc_lifecycle_data, perform_queue_deletion
from test.case_queue_test_vars import post_case_queue_var, queue_id, del_case_queue, post_document_var, \
    del_document_var, solution_id, template_id, \
    del_false_case_queue,update_case_queue

tracer = trace.Tracer.get_instance(SERVICE_NAME)
context = tracer.get_context(request_id=str(uuid4()), log_level="ERROR")
context.start_span(component=__name__)


post_case_queue_var()
post_case_queue_var({"queue_id": 000000})
post_document_var()
payload_msg = {"file_name": "Resume", "doc_id": "684a62d9-5723-4b31-a27b-7e4e42ab9688",
                                      "assignee": "default_bu",
                                      "status": "New",
                                      "queue_id": 000000,
                                      "doc_state": "classified"}
a_test_1 = {}
a_test_2 = {"file_name": "Resume"}
a_test_3 = {"file_name": "Resume", "doc_state": "classified"}
a_test_4 = {"file_name": "Resume", "doc_state": "classified", "doc_id": "7e4e42ab9688"}
a_test_5 = {"file_name": "Resume", "doc_state": "classified", "doc_id": "7e4e42ab9688", "assignee": "default_bu"}
a_test_6 = {"file_name": "Resume", "doc_state": "classified", "doc_id": "7e4e42ab9688", "assignee": "default_bu",
            "status": "New"}
a_test_7 = {"file_name": "Resume", "doc_state": "classified", "doc_id": "7e4e42ab9688","queue_id":000000}
b_test = {"status": "test", "doc_state": "test", "queue_id": 000000, "case_id": "test"}
b_test_1 = {}
b_test_2 = {"status": "test"}
b_test_3 = {"status": "test", "doc_state": "test"}
b_test_4 = {"status": "test", "doc_state": "test", "queue_id": 000000}
ele = {'assignee': None, 'assigned_ts': None, 'status': 'New', 'queue_name': 'processing', 'closed_ts': None,
       'is_assigned': False, 'queue_id': 000000}
queue_dict = {'processing': {}}
q_name = 'processing'
false_queue_id = 000000


@pytest.mark.parametrize("test_msg, expected",
                         [
                             (payload_msg, (None, True)),
                             (a_test_1, ({'status': 'failure', 'msg': 'filename is not provided.'}, False)),
                             (a_test_2, ({'status': 'failure', 'msg': 'document state is not provided.'}, False)),
                             (a_test_3, ({'status': 'failure', 'msg': 'Case Id is not provided.'}, False)),
                             (a_test_4, ({'status': 'failure', 'msg': 'Please provide either queue_id or assignee name.'}, False)),
                             (a_test_5, ({'status': 'failure', 'msg': 'Document status is not provided.'},
                                         False)),
                             (a_test_6, (None, True)),
                             (a_test_7, ({'status': 'failure', 'msg': 'Document status is not provided.'},
                                         False))
                         ])
def test_validate_payload(test_msg, expected):
    response = validate_payload(test_msg)
    assert response == expected


def test_fetch_temp_soln_id_from_case_queue():
    response = fetch_temp_soln_id_from_case_queue(context, None, false_queue_id)
    assert response == ([], [], [])





def test_fetch_agent_list():
    res = fetch_agent_list(false_queue_id, context)
    assert res == []
    res = fetch_agent_list(queue_id, context)
    assert res is not None


@pytest.mark.parametrize("test_msg, expected",
                         [
                            (b_test, True),
                            (b_test_1, False),
                            (b_test_2, False),
                            (b_test_3, False),
                            (b_test_4, False)])
def test_validate_payload(test_msg, expected):
    response = validate_payload(test_msg)
    assert response == expected





def test_get_queue_details():
    response = get_queue_details("post_processed", context, template_id, solution_id)
    assert response == (None, None)


def test_get_default_doc_lifecycle_data():
    response = get_default_doc_lifecycle_data("post_processed", context, template_id, solution_id)
    assert type(response) == dict
    assert "is_assigned" and 'assignee' and 'assigned_ts' and 'closed_ts' and 'status' in response.keys()









def test_request_data_validation():
    res = request_data_validation(000000)
    assert res == False


@pytest.mark.parametrize("test_msg, expected",
                         [
                            ({"solution": [], "solution_id": [], "agents": [], "processing_state": []},
                             {"solution": [], "solution_id": [], "agents": [], "processing_state": []}),
                             ({"solution": "test,var", "solution_id": [], "agents": [], "processing_state": []},
                              {"solution": "test,var", "solution_id": [], "agents": [], "processing_state": []}),
                             ({"solution": [], "agents": "var,test", "processing_state": []},
                              {"solution": [], "agents": ["var", "test"], "processing_state": []}),
                             ({"solution": [], "processing_state": "var,test", "agents": []},
                              {"solution": [], "processing_state": ["var", "test"], "agents": []})
                         ])
def test_update_data_dict(test_msg, expected):
    response = update_data_dict(test_msg)
    assert response == expected


def test_insert_queue():
    response = insert_queue({}, q_name, context)
    assert response == {"status": "success", "msg": "Queue processing created Successfully."}


def test_update_queue():
    response = update_queue({}, q_name, queue_id, context)
    assert response == {"status": "success", "msg": "Queue processing updated Successfully."}


def test_prepare_returning_data_json():
    res = prepare_returning_data_json([], "test_data", "test_list", "test", "test")
    assert type(res) == dict


def test_delete_queue():
    response = delete_queue(context, "")
    assert response == {'status': 'failure', 'msg': 'Failed to remove queue.'}
    response = delete_queue(context, 0)
    assert response == {'status': 'success', 'msg': 'Queue has been removed successfully.'}


def test_perform_queue_deletion():
    response = perform_queue_deletion("test_f_1234_id", context)
    assert response == {'status': 'failure', 'msg': 'Failed to remove queue.'}





del_case_queue()
del_false_case_queue({"queue_id": 000000})
update_case_queue({"queue_id": 0})


@pytest.mark.run(order=1000)
def del_doc():
    return del_document_var()

del_doc()

def test_insert_variables():
    sol_id = str(uuid4())
    data=insert_variables(sol_id)
    assert data == sol_id

def test_get_doc_case_variable():
    sol_id = str(uuid4())
    #data = insert_variables(sol_id)
    res = get_doc_case_variable(sol_id)
    assert len(res) > 0



import requests, json, uuid, traceback, os, mimetypes, time
from datetime import datetime
from config_vars import API_GATEWAY_POST_JOB_URI, API_GATEWAY_JOB_STATUS_URI
import math

headers = {'Content-Type': 'application/json'}
create_rule_endpoint = ""


def get(url, headers1=headers):
    resp = dict()
    resp['status'] = 'failure'
    try:
        r = requests.get(url, headers=headers1)
        if r.status_code == 200:
            try:
                response_json = json.loads(r.text)
            except:
                response_json = ""
            resp['status'] = 'success'
            resp['result'] = response_json
        else:
            resp['msg'] = r.text
        resp['status_code'] = r.status_code
    except Exception as e:
        print(str(e))
        print('Failed in processing GET API (' + url + ')')
    return resp


def post(url, payload, headers1=headers):
    resp = dict()
    resp['status'] = 'failure'
    try:
        r = requests.post(url, data=json.dumps(payload), headers=headers1)
        response_json = json.loads(r.text)
        if int(r.status_code) == 200:
            resp['status'] = 'success'
            resp['result'] = response_json
        else:
            resp['msg'] = r.text
        resp['status_code'] = r.status_code
    except:
        print('Failed in processing POST API (' + url + ')')
    return resp


def put(url, payload, headers1=headers):
    resp = dict()
    resp['status'] = 'failure'
    try:
        r = requests.put(url, data=json.dumps(payload), headers=headers1)
        response_json = json.loads(r.text)
        if int(r.status_code) == 200:
            resp['status'] = 'success'
            resp['result'] = response_json
        else:
            resp['msg'] = r.text
        resp['status_code'] = r.status_code
    except:
        print('Failed in processing POST API (' + url + ')')
    return resp


def delete(url, headers1=headers):
    resp = dict()
    resp['status'] = 'failure'
    try:
        r = requests.delete(url, headers=headers1)
        response_json = json.loads(r.text)
        if int(r.status_code) == 200:
            resp['status'] = 'success'
            resp['result'] = response_json
        else:
            resp['msg'] = r.text
        resp['status_code'] = r.status_code
    except:
        print('Failed in processing DELETE API (' + url + ')')
    return resp


def get_success_response(msg):
    resp = dict()
    resp['status'] = 'success'
    if msg is None:
        msg = 'Success'
    resp['msg'] = msg


def get_failure_response(msg):
    resp = dict()
    resp['status'] = 'failure'
    if msg is None:
        msg = 'Failed'
    resp['msg'] = msg
    return resp


def post_job(endpoint, data, timeout=300):
    dt = datetime.now()
    job_res = post(API_GATEWAY_POST_JOB_URI + endpoint, data)
    if is_exists(job_res, 'result') and is_exists(job_res['result'], 'job_id'):
        job_id = job_res['result']['job_id']
        i = 1
        while True:
            time.sleep(math.pow(1.5, i))
            curr_date = datetime.now()
            if (curr_date - dt).total_seconds() > timeout:
                return {'success': False, 'msg': 'Timeout', "job_id":job_id}
            resp = get(API_GATEWAY_JOB_STATUS_URI + job_id)
            if is_exists(resp, 'result') and is_exists(resp['result'], 'process_status'):
                if (resp['result'])['process_status'] == 'processed':
                    resp["job_id"] = job_id
                    return resp
            if i > 6:
                i = 1
            else:
                i += 1
    return job_res


def is_exists(data, key):
    try:
        if "." in key:
            keys = key.split(".")
        else:
            keys = [key]

        for itm in keys:
            if isinstance(data, list):
                if data != [] and itm in data[0].keys() and data[0][itm] is not None:
                    return True
            else:
                if data is not None and itm in data.keys() and data[itm] is not None:
                    return True
            return False
    except:
        return False


def get_nested_value(document, field):
    try:
        if "." in str(field):
            keys = str(field).split(".", 1)
        else:
            keys = [field]
        itm = keys[0].strip()
        if isinstance(document, dict) and itm in document.keys():
            if len(keys) == 1:
                return document[itm]
            else:
                return get_nested_value(document[itm], str(keys[1]))
        elif isinstance(document, list) and is_int(itm):
            if len(keys) == 1 and len(document) > 0:
                return document[int(itm)]
            else:
                return get_nested_value(document[int(itm)], str(keys[1]))
        else:
            return None
    except:
        return None


def is_int(s):
    try:
        int(s)
        return True
    except ValueError:
        return False


def is_message_published(response):
    result = response['result'] if response is not None and 'result' in response.keys() else None
    if result is not None and 'status' in result.keys() and result['status']['success']:
        return True
    return False


def get_response(response):
    result = response['result'] if response is not None and 'result' in response.keys() else None
    if result is None or 'status' not in result.keys():
        return False, {'success': False, 'msg': 'Not a valid response', 'error': result}
    if result['status']['success']:
        return True, None
    return False, result['status']


def is_request_timeout(response):
    return True if response is not None and 'msg' in response.keys() and 'Timeout' == response['msg'] else False
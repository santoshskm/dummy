from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt

from services.solutions import solution_request, get_solution_id
from services.tenants import tenants_active
from services.uam import auth_user, auth_user_info
from services.user_services import UserServices
from services.case_queue import case_queue_services

@csrf_exempt
def auth(request):
    return JsonResponse(auth_user(request))


@csrf_exempt
def case_queue_management(request):
    return JsonResponse(case_queue_services(request), safe=False)


@csrf_exempt
def update_case_queue(request):
    return JsonResponse(case_queue_services(request), safe=False)


@csrf_exempt
def delete_case_queue(request, queue_id):
    return JsonResponse(case_queue_services(request, queue_id=queue_id),
                        safe=False)



@csrf_exempt
def auth_info(request):
    return JsonResponse(auth_user_info(request))


@csrf_exempt
def solution(request, sol_info=''):
    return JsonResponse(solution_request(request, sol_info), safe=False)


@csrf_exempt
def get_solution(request):
    return JsonResponse(get_solution_id(request), safe=False)


@csrf_exempt
def active_tenants(request):
    return tenants_active(request)



@csrf_exempt
def user_groups(request, ug_id=None):
    ug_obj = UserServices()
    return JsonResponse(ug_obj.process_user_groups_request(request,
                                                           user_group_id=ug_id),
                        safe=False)


@csrf_exempt
def user_roles(request, role_id=None, user_id=None):
    ug_obj = UserServices()
    return JsonResponse(ug_obj.process_user_roles_request(request,
                                                          role_id=role_id, user_id=user_id),
                        safe=False)


@csrf_exempt
def user_roles_linkusers(request, ug_id=None, role_id=None):
    ug_obj = UserServices()
    return JsonResponse(ug_obj.process_users_linking_roles_request(request,
                                                                   ug_id=ug_id,
                                                                   role_id=role_id),
                        safe=False)


@csrf_exempt
def implement_users(request, user_id=None):
    ug_obj = UserServices()
    return JsonResponse(ug_obj.process_user_request(request,
                                                    user_id=user_id),
                        safe=False)


@csrf_exempt
def link_users(request, ug_id=None, user_id=None):
    ug_obj = UserServices()
    return JsonResponse(ug_obj.process_users_linking_request(request,
                                                             ug_id=ug_id,
                                                             user_id=user_id),
                        safe=False)


@csrf_exempt
def handle_user_solutions(request):
    res = {"status": "success", "data": UserServices().process_user_solutions(request)}
    return JsonResponse(res, safe=False)


@csrf_exempt
def get_agents_list(request):
    return JsonResponse(fetch_agents(request), safe=False)
from django.conf.urls import url
from api import views

urlpatterns = [
    # Case Queue Management APIs

    # AUTHORIZATION APIs
    url(r'^auth/', views.auth, name="Authorization"),
    url(r'^auth/info', views.auth_info, name="Get Logged-in User Info"),

    # PLATFORM APIs
    # 1. Solution Api
    url(r'^soln/$', views.solution),
    url(r'^soln/(?P<sol_info>\w+)/$', views.solution),
    url(r'^activeTenant/', views.active_tenants),
    url(r'^get/solnid/', views.get_solution),

    url(r'^queue/agents', views.get_agents_list, name="Queue Management"),
    url(r'^createqueue/$', views.case_queue_management, name="Queue Management"),
    url(r'^getqueues/$', views.case_queue_management, name="Queue Management"),
    url(r'^updatequeue/$', views.update_case_queue, name="Queue Management"),
    url(r'^deletequeue/(?P<queue_id>[\w\-]+)/$',
        views.delete_case_queue, name="Queue Management"),
    # User Groups APIs
    url(r'^usergroups/$', views.user_groups),
    url(r'^usergroups/(?P<ug_id>[\w\-]+)/$', views.user_groups),
    url(r'^nestedusergroups/(?P<ug_id>[\w\-]+)/$', views.user_groups),
    url(r'^userroles/$', views.user_roles),
    url(r'^userroles/(?P<role_id>[\w\-]+)/$', views.user_roles),
    url(r'^userroles/(?P<role_id>[\w\-]+)/users/(?P<user_id>[\w\-]+)/$', views.user_roles),
    url(r'^linkuserstorole/$', views.user_roles_linkusers),
    url(r'^users/$', views.implement_users),
    url(r'^users/(?P<user_id>[\w\-]+)/$', views.implement_users),
    url(r'^solutions/$', views.handle_user_solutions),
    url(r'^linkusers/$', views.link_users),
    url(r'^linkusers/(?P<ug_id>[\w\-]+)/(?P<user_id>[\w\-]+)/$',
        views.link_users),

]

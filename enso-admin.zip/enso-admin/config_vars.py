import os, ast

CASE_ACTIVATED = ast.literal_eval(os.environ['CASE']) if 'CASE' in os.environ else True
ROOT = os.path.dirname(os.path.abspath(__file__))
MEDIA_ROOT = os.path.join(ROOT, 'media/')
SCRIPTS_ROOT = os.path.join(ROOT, "scripts/")

if not os.path.exists(MEDIA_ROOT):
    os.makedirs(MEDIA_ROOT)

# Mount path ops
MOUNT_PATH = os.environ["SHARED_VOLUME"]
MOUNT_PATH = MOUNT_PATH if MOUNT_PATH.endswith("/") else MOUNT_PATH + "/"

# API gateway
HTTP_PROTO = 'http://'
API_GATEWAY_POST_JOB_URI = HTTP_PROTO + os.environ["API_GATEWAY_URL"]
API_GATEWAY_POST_JOB_URI = API_GATEWAY_POST_JOB_URI if API_GATEWAY_POST_JOB_URI.endswith("/") \
    else API_GATEWAY_POST_JOB_URI + "/"
API_GATEWAY_JOB_STATUS_URI = API_GATEWAY_POST_JOB_URI + "job/"

SOLUTION_ID = "test"

DEFAULT_SOLN_NAME = 'default'

# Solution Settings
SOLN = {"collection": "tenant"}

# New Solution trigger
NEW_SOLN_TRIGGER = 'solution/new'

# MongoDb params
DB_HOST_MONGO = os.environ["DB_HOST_MONGO"]
DB_PORT_MONGO = os.environ["DB_PORT_MONGO"]
DB_USERID_MONGO = os.environ["DB_USERID_MONGO"]
DB_PASSWORD_MONGO = os.environ["DB_PASSWORD_MONGO"]
DB_AUTH_NM_MONGO = os.environ["DB_AUTH_NM_MONGO"]

DOCUMENTS_COLLECTION = "console_documents"
DOC_ELEMENTS_COLLECTION = "console_doc_elements"
DOC_MAPPING_COLLECTION = "console_doc_mapping"
DOC_SECTIONS_COLLECTION = "console_doc_sections"
TEMPLATE_TEST_COLLECTION = "template_test"
RESOURCES_COLLECTION = "resources"
WORKFLOW_COLLECTION = "workflows"
CASE_QUEUE_COLLECTION = "case_queue"
DOC_CASE_COLLECTION = "workflow_variables"
RULES_COLLECTION = "console_rules"
TEMPLATE_COLLECTION = "console_document_templates_new"


RULES_ENDPOINT = {
    "SAVE": "saveResource",
    "GET": "getResource",
    "ADD": "saveResource",
    "DELETE": "deleteResourceElement",
    "search": "search",
    "get_rule": "getRule",
    "get_tags": "getResources",
    "get_hierarchy": "hierarchy",
    "del_tag": "deleteResource"
}


SERVICE_NAME = "enso-admin"

STATUS_CODES = {
    'OK': 200,
    'CREATED': 201,
    'DELETED': 202,
    'NON_AUTHORATIVE': 203,
    'NO_CONTENT': 204,
    'FOUND': 302,
    'BAD_REQUEST': 400,
    'UNAUTHORIZED': 401,
    'FORBIDDEN': 403,
    'NOT_FOUND': 404,
    'METHOD_NOT_ALLOWED': 405,
    'NOT_ACCEPTABLE': 406,
    'PROXY_AUTH_REQUIRED': 407,
    'REQUEST_TIMEOUT': 408,
    'CONFLICT': 409,
    'PRECONDITION_FAILED': 412,
    'PAYLOAD_TOO_LARGE': 413,
    'URI_TOO_LONG': 414,
    'UNSUPPORTED_MEDIA': 415,
    'MISDIRECTED_REQUEST': 421,
    'UNPROCESSABLE_ENTITY': 422,
    'LOCKED': 423,
    'PRECONDITION_REQUIRED': 428,
    'TOO_MANY_REQUESTS': 429,
    'UNAVAILABLE_FOR_LEGEL_REASON': 451,
    'INTERNAL_SERVER_ERROR': 500,
    'NOT_IMPLEMENTED': 501,
    'BAD_GATEWAY': 502,
    'SERVICE_UNAVAILABLE': 503,
    'GATEWAY_TIMEOUT': 504,
    'INSUFFICIENT_STORAGE': 507,
    'NETWORK_AUTHENTICATION_REQUIRED': 511
}

WORKFLOW_QUEUE_COLLECTION = 'workflow_queue'


# Key_Cloak service integration points
KEY_CLOAK_API_URI = HTTP_PROTO + os.environ['ADMIN_API_URL']
KEY_CLOAK_API_URI += ':' + os.environ['ADMIN_API_PORT']
KEY_CLOAK_API_URI = KEY_CLOAK_API_URI if KEY_CLOAK_API_URI.endswith("/") \
    else KEY_CLOAK_API_URI + "/"
KEY_CLOAK_USER_GROUPS_ENDPOINT = 'groups'
KEY_CLOAK_USER_ROLES_ENDPOINT = 'roles'
KEY_CLOAK_USERS_ENDPOINT = 'users'

# Solution Collection
SOLUTION_COLLECTION = 'solutions'

DOC_COUNT = 1000

# Sources Collection
SOURCES_COLLECTION = 'sources'

THRESHOLD_COLLECTION = 'thresholds'


HTTP_PROTOC = 'http://'
CASE_MANAGEMENT_SERVICE_URL = HTTP_PROTOC + os.getenv("CASE_MANAGEMENT_SERVICE_URL")
CASE_MANAGEMENT_SERVICE_URL = CASE_MANAGEMENT_SERVICE_URL if CASE_MANAGEMENT_SERVICE_URL.endswith("/") \
    else CASE_MANAGEMENT_SERVICE_URL + "/"

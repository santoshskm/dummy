#!/usr/bin/env bash
cd uam
chmod +x gulp.sh
sh gulp.sh

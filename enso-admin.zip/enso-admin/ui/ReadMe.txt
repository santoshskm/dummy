#Build command

sudo -s
sh build.sh


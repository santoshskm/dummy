(function() {
	'use strict';

	angular.module('console.login.services', [])
		.service('AuthService', require('./authServices'));
})();




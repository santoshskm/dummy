import json
import traceback

from config_vars import TEMPLATE_COLLECTION
from connections.mongodb import MongoDbConn

def get_template(solution_id, template_type="", payload={}):
    try:
        unknown_types = ["unknown_known", "unknown_unknown"]
        query = dict(solution_id=solution_id, is_deleted=False)
        t = MongoDbConn.find(TEMPLATE_COLLECTION, query, {"_id": 0})
        templates = list()
        for a in t:
            a = json.loads(a["template"])
            a["template_id"] = a["doc_id"]
            templates.append(a)

        if template_type != "":
            if template_type == "allpublished":
                templates = [a for a in templates if not a["is_draft"] or a["template_type"] in unknown_types]
            else:
                template_type = unknown_types if template_type == "unknown" else [template_type]
                templates = [a for a in templates if a["template_type"] in template_type]

        count = len(templates)
        page_no = payload["page_no"] if "page_no" in payload else None
        limit = payload["no_of_recs"] if "no_of_recs" in payload else None
        if page_no and count > limit:
            skip = (int(page_no) - 1) * limit
            templates = templates[skip:skip + limit]

        return dict(success=True, msg="Template data", data=templates, total_count=count, status="success")
    except Exception:
        return dict(success=False, error=traceback.format_exc(), msg="Failed to get template", status="failure")

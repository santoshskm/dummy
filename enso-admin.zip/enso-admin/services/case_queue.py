"""
@author: Rohit Kumar Jaju
@date: June 21, 2018
@purpose: The functions mentioned in this python file are responsible
          for all kind of Case Queue Management related CRUD operations.
          All functions are exposed as APIs.
"""
import json, requests
from uuid import uuid4
from datetime import datetime
from connections.mongodb import MongoDbConn
from utilities.common import get_solution_from_session, create_data,\
    save_file_fetched_from_efs
from config_vars import SERVICE_NAME, CASE_QUEUE_COLLECTION,\
    DOCUMENTS_COLLECTION, WORKFLOW_QUEUE_COLLECTION,\
    STATUS_CODES, WORKFLOW_COLLECTION, CASE_MANAGEMENT_SERVICE_URL
from xpms_common import trace
import traceback

from random import randint
from config_vars import DOC_CASE_COLLECTION, SOLUTION_COLLECTION
from services.rules import update_rule
from services.user_services import UserServices
from services.template import get_template

us_obj = UserServices()
tracer = trace.Tracer.get_instance(SERVICE_NAME)

display_to_d_state = {'Review Classification': 'classified',
                      'Review Text Extraction': 'extracted',
                      'Review Entity Linking': 'entity_linked'}

def fetch_agent_list(queue_id, context):
    """
    This function will fetch all the agents
    which are associated with the queue
    :param queue_id: queue_id
    :param context: logger object
    :return: agent_list
    """
    try:
        query = {'queue_id': int(queue_id)}
        projection = {'agents': 1, '_id': 0}
        agents_cur = MongoDbConn.find_one(CASE_QUEUE_COLLECTION, query,
                                      projection=projection)
        if agents_cur:
            return agents_cur['agents']
        return []
    # TODO raise specific exception
    except Exception as e:
        context.log(message=str(e), obj={"tb": traceback.format_exc()})
        return []


def validate_payload(payload):
    """
    This function will validate the requested payload
    and return the boolean response
    :param payload: requested payload
    :return: validation flag
    """
    if 'status' not in payload:
        return False
    if 'doc_state' not in payload:
        return False
    if 'queue_id' not in payload:
        return False
    if 'case_id' not in payload:
        return False
    return True


def fetch_temp_soln_id_from_case_queue(context, sv_user=None,
                                       queue_id=None):
    """
    This function will fetch the templates id from case queue collection
    and return list of templates id and solution id
    :param context: Logger Object
    :param sv_user: supervisor user
    :param queue_id: queue_id
    :return: list of all template id and solution id
    from case queue collection
    """
    try:
        query = {}
        projection = {'_id': 0, 'document_type': 1, 'solution_id': 1,
                      'queue_name': 1}
        if sv_user:
            query.update({'supervisor': sv_user})
        if queue_id:
            query.update({'queue_id': int(queue_id)})
        temp_records = MongoDbConn.find(CASE_QUEUE_COLLECTION, query,
                                        projection=projection)
        if temp_records:
            temp_list = []
            soln_list = []
            queue_name = []
            for item in temp_records:
                for ele in item['document_type']:
                    temp_list.append(ele)
                soln_list.extend(item['solution_id'])
                queue_name.append(item['queue_name'])
            return temp_list, soln_list, queue_name
        else:
            return [], [], []
    # TODO raise specific exception
    except Exception as e:
        context.log(message=str(e), obj={"tb": traceback.format_exc()})
        return [], [], []

def get_queue_name(queue_id, context, queue_name=True):
    """
    This method will fetch the queue name based on the queue_id
    :param queue_id: Queue unique identifier
    :param context: Logger object
    :return: queue name
    """
    try:
        query = {'queue_id': queue_id}
        if queue_name:
            projection = {'queue_name': 1, '_id': 0}
            return MongoDbConn.find_one(CASE_QUEUE_COLLECTION,
                                    query,
                                    projection=projection)['queue_name']
        else:
            projection = {'_id': 0}
            return MongoDbConn.find_one(CASE_QUEUE_COLLECTION,
                                        query,
                                        projection=projection)
    except Exception as e:
        context.log(message=str(e), obj={"tb": traceback.format_exc()})
        return None


def case_queue_services(request, queue_id=None):
    """
    This function is providing the functionalities to create new case queue,
    delete any existing queue(conditions applied), get all existing case queues
    with all relevent data
    :param request: request to be processed
    :param queue_id: queue to be deleted
    :return: Json Response
    """
    context = tracer.get_context(request_id=str(uuid4()), log_level="ERROR")
    context.start_span(component=__name__)
    try:
        # solution_id = get_solution_from_session(request)
        # GET all case queues related data
        if request.method == 'GET':
            return fetch_case_queue_data(request, context)
        # Create new case queue
        elif request.method == 'POST':
            try:
                payload = json.loads(request.body.decode())
            except:
                payload = request.POST
            queue_name = payload['queue_name']
            if payload:
                return create_case_queue(payload, context)
            else:
                return {'status': 'failure',
                        'msg': 'Failed to create ' + queue_name + ' queue.'}
        # Delete case queue(conditional)
        elif request.method == 'DELETE':
            return delete_queue(context, queue_id)
    # TODO raise specific exception
    except Exception as e:
        context.log(message=str(e), obj={"tb": traceback.format_exc()})
    finally:
        context.end_span()


def delete_queue(context, queue_id):
    """
    This function will mark queue as deleted queue in db
    :param context: Logger object
    :param queue_id: queue to be deleted
    :return: Json response
    """
    if (queue_id is None) or (queue_id == ''):
        return {'status': 'failure', 'msg': 'Failed to remove queue.'}
    return perform_queue_deletion(queue_id, context)


def perform_queue_deletion(queue_id, context):
    """
    This function will actually performing queue deletion operation
    :param queue_id: case queue to be deleted
    :param context: Logger object
    :return: Json response
    """
    try:
        query = {'queue_id': int(queue_id)}
        data_dict = {'is_deleted': True,
                     'modified_ts': datetime.now()}
        MongoDbConn.update(CASE_QUEUE_COLLECTION, query, data_dict)
        return {'status': 'success',
                'msg': 'Queue has been removed successfully.'}
    # TODO raise specific exception
    except Exception as e:
        context.log(message=str(e), obj={"tb": traceback.format_exc()})
        return {'status': 'failure', 'msg': 'Failed to remove queue.'}


def fetch_all_solutions(context):
    """
    This function returns the all solution_id and solution name
    in the form of list of dictionaries
    :param context: Logger object
    :return: Solution_id and name mapping in the form of list of
    dictionaries
    """
    query = {'is_deleted': False}
    projection = {'_id': 0}
    solns_data = MongoDbConn.find(SOLUTION_COLLECTION, query,
                                  projection=projection).sort('updated_ts', -1)
    soln_list = []
    soln_name_list = []
    soln_agents_mapping = dict()
    soln_sv_mapping = dict()
    soln_other_mapping = dict()
    if not solns_data:
        return soln_list, soln_name_list, soln_agents_mapping, soln_sv_mapping
    solns = solns_data
    obj = UserServices()
    users_list = obj.get_users_list()
    for s_obj in solns:
        soln_name = s_obj['solution_name']
        soln_id = s_obj['solution_id']
        soln_id_name_dict = dict()
        soln_id_name_dict['solution_id'] = soln_id
        soln_id_name_dict['solution_name'] = soln_name
        if isinstance(users_list,dict) and "result" in users_list.keys():
            if "data" in users_list["result"].keys():
                users_list = users_list["result"]["data"]
        for user in users_list:
            user_name = user['userName']
            soln_found = False
            if 'solutions' in user and user['solutions']:
                for sln in user['solutions']:
                    if sln['id'] == soln_id:
                        soln_found = True
                        break
            if not soln_found:
                continue
            if 'userRoles' in user and user['userRoles']:
                for role in user['userRoles']:
                    if role['name'] == 'bu':
                        if soln_name not in soln_agents_mapping:
                            soln_agents_mapping[soln_name] = []
                        soln_agents_mapping[soln_name].append(user_name)
                    elif role['name'] == 'sv':
                        if soln_name not in soln_sv_mapping:
                            soln_sv_mapping[soln_name] = []
                        soln_sv_mapping[soln_name].append(user_name)
                    else:
                        if soln_name not in soln_other_mapping:
                            soln_other_mapping[soln_name] = []
                        soln_other_mapping[soln_name].append(user_name)
        soln_name_list.append(soln_name)
        soln_list.append(soln_id_name_dict)
    return soln_list, soln_name_list, soln_agents_mapping,\
           soln_sv_mapping, soln_other_mapping


def fetch_case_queue_data(request, context):
    """
    This function will fetch all case queue data from db collection and return
    :param request: request to be processed
    :param context: Logger Object
    :return: Json Response with all fetched case queue data
    """
    try:
        queue_data = fetch_queue_db_data(context)
        solution_id_dict, soln_name_list, soln_agents_mapping, soln_sv_mapping, other_mapping = \
            fetch_all_solutions(context)
        solution_name_temp_dict = prepare_soln_temp_mapping(request,
                                                            solution_id_dict)
        # supervisors = fetch_users_list(context)
        if queue_data:
            data = prepare_returning_data_json(queue_data,
                                               solution_name_temp_dict,
                                               soln_name_list,
                                               soln_sv_mapping, soln_agents_mapping)
            return {"status": "success",
                    "data": data,
                    "msg": "successfully returned case queue data"}
        else:
            return {"status": "failure",
                    "msg": "Failed to fetch data from DB"}
    # TODO raise specific exception
    except Exception as e:
        context.log(message=str(e), obj={"tb": traceback.format_exc()})
        return {"status": "failure", "msg": "Failed to fetch data from DB"}


def fetch_queue_db_data(context):
    """
    This function will fetch the data from case_queue collection
    and return
    :param context: Logger object
    :return: fetch and return the data fetched from db
    """
    try:
        query = {'is_deleted': False}
        projection = {'_id': 0}
        queue_data = MongoDbConn.find(CASE_QUEUE_COLLECTION,
                                      query, projection=projection)
        return queue_data.sort('modified_ts', -1)
    # TODO raise specific exception
    except Exception as e:
        context.log(message=str(e), obj={"tb": traceback.format_exc()})
        return None


def prepare_soln_temp_mapping(request, solution_id_dict):
    """
    This function will map all solutions with its corresponding templates
    :param request: request to be processed
    :param solution_id_dict: mapping of solution_id and solution_name
    :return: mapping of solution with templates
    """
    solution_name_temp_dict = dict()
    for soln_id in solution_id_dict:
        temp_soln_id = soln_id['solution_id']
        temp_dict = get_template(solution_id=temp_soln_id,
                                  template_type='allpublished')
        if temp_dict['status'] == 'success':
            temp_list = [dict(template_id=temp["template_id"], template_name=temp["template_name"]) for temp in
                         temp_dict["data"]]
        temp_list.extend([{'template_id': 'unknown',
                           'template_name': 'unknown'}])
        for item in temp_list:
            item.update({'solution_id': soln_id['solution_id']})
        solution_name_temp_dict[soln_id['solution_name']] = temp_list
    return solution_name_temp_dict


def prepare_returning_data_json(queue_data, solution_name_temp_dict,
                                soln_name_list, soln_sv_mapping, agents):
    """
    This function prepares the returning data json
    :param queue_data: DB data for all existing queues
    :param solution_name_temp_dict: dictionary consists of
           solution and templates mapping
    :param soln_name_list: list of all solutions
    :param supervisors: list of all active supervisors
    :param agents: list of all active agents/bu_users
    :return: data dictionary
    """
    data = dict()
    all_queue_data = []
    for item in queue_data:
        all_queue_data.append(item)
    data['all_queues'] = all_queue_data
    data['doc_state'] = display_to_d_state
    data['soln_template_data'] = solution_name_temp_dict
    data['solutions'] = soln_name_list
    data['supervisors'] = soln_sv_mapping
    data['agents'] = agents
    return data


def create_case_queue(payload, context):
    """
    This method will process the payload provided and create the new case
    queue if payload passes all required validations
    :param payload: request payload to create new case queue
    :param context: Logger object
    :param queue_name: name of the case queue which needs to be created
    :return: Json Response
    """
    try:
        data_dict = create_data(payload)
        data_dict = update_data_dict(data_dict)
        queue_name = "default"
        if 'queue_name' in payload:
            queue_name = payload['queue_name']
        else:
            state = payload["processing_state"][0]
            for key,value in display_to_d_state.items():
                if value == state:
                    queue_name = key
            data_dict['queue_name'] = queue_name

        if 'queue_id' not in payload:
            return insert_queue(data_dict, queue_name,
                                context)
        else:
            queue_id = int(payload['queue_id'])
            return update_queue(data_dict,
                                queue_name, queue_id, context)
    # TODO raise specific exception
    except Exception as e:
        context.log(message=str(e), obj={"tb": traceback.format_exc()})
        return {'status': 'failure', 'msg': 'Failed to create '
                                            + queue_name + ' queue.'}


def update_queue(data_dict, queue_name, queue_id, context):
    """
    This function will update the case queue in db
    :param data_dict: data to be inserted
    :param queue_name: name of the queue
    :param queue_id: queue to be updated
    :param context: logger object
    :return: Json response
    """
    try:
        data_dict.update({'modified_ts': datetime.now(),
                          'queue_id': queue_id,
                          'is_deleted': False})
        MongoDbConn.update(CASE_QUEUE_COLLECTION,
                           {'queue_id': queue_id},
                           data_dict)
        return {"status": "success", "msg": "Queue " + queue_name +
                                            " updated Successfully."}
    # TODO raise specific exception
    except Exception as e:
        context.log(message=str(e), obj={"tb": traceback.format_exc()})
        return {'status': 'failure', 'msg': 'Failed to update '
                                            + queue_name + ' queue.'}


def insert_queue(data_dict, queue_name, context):
    """
    This function will create a new case queue in db
    :param data_dict: data to be inserted
    :param queue_name: name of the queue
    :param context: Logger object
    :return: Json response
    """
    try:
        queue_id = randint(100000, 999999)
        while not request_data_validation(queue_id):
            queue_id = randint(100000, 999999)
        data_dict.update({'created_ts': datetime.now(),
                          'modified_ts': datetime.now(),
                          'queue_id': queue_id,
                          'is_deleted': False})
        MongoDbConn.insert(CASE_QUEUE_COLLECTION, data_dict)
        return {"status": "success", "msg": "Queue " + queue_name +
                                            " created Successfully."}
    # TODO raise specific exception
    except Exception as e:
        context.log(message=str(e), obj={"tb": traceback.format_exc()})
        return {'status': 'failure', 'msg': 'Failed to create '
                                            + queue_name + ' queue.'}


def update_data_dict(data_dict):
    """
    This function will update the data_dict for some fields
    :param data_dict:
    :return: updated data_dict
    """
    if 'agents' in data_dict:
        if type(data_dict['agents']) == str:
            data_dict['agents'] = data_dict['agents'].split(',')
    else:
        data_dict['agents'] = []
    if 'supervisor' in data_dict:
        if type(data_dict['supervisor']) == str:
            data_dict['supervisor'] = data_dict['supervisor'].split(',')
    if 'processing_state' in data_dict:
        if type(data_dict['processing_state']) == str:
            data_dict['processing_state'] = data_dict['processing_state'].split(',')
    return data_dict


def request_data_validation(queue_id):
    """
    This function will validate the input data provided for
    creation of the case queue.
    :param queue_id: queue_id to be validated
    :return: Boolean flag. If input data is valid
    then return True else False
    """
    valid_flag = True
    query = {'queue_id': int(queue_id)}
    projection = {'_id': 0}
    queue_data = MongoDbConn.find_one(CASE_QUEUE_COLLECTION, query,
                                      projection=projection)
    if queue_data:
        valid_flag = False
    return valid_flag


def prepare_doc_life_cycle_data(doc_state, data, context):
    """
    This function will prepare and return the updated payload data
    with updated life cycle data of the document
    :param doc_state: current state of the document
    :param data: payload data
    :param context: Logger Object
    :return: updated payload data
    """
    try:
        template_id = data['template_id'] if 'template_id' in data else None
        solution_id = data['solution_id'] if 'solution_id' in data else None
        document_info = MongoDbConn.find_one(DOCUMENTS_COLLECTION,{'doc_id':data['doc_id']})
        if 'life_cycle' in document_info:
            queue_id = None
            if doc_state in document_info['life_cycle']:
                queue_id = document_info['life_cycle'][doc_state]['queue_id']
            if queue_id is None:
                doc_life_cycle_data = get_default_doc_lifecycle_data(doc_state,
                                                                     context,
                                                                     template_id,
                                                                     solution_id)
                data['life_cycle'] = document_info['life_cycle']
                data['life_cycle'][doc_state] = doc_life_cycle_data
        else:
            doc_life_cycle_data = get_default_doc_lifecycle_data(doc_state,
                                                                 context,
                                                                 template_id,
                                                                 solution_id)
            temp_doc_state_dict = dict()
            temp_doc_state_dict[doc_state] = doc_life_cycle_data
            data['life_cycle'] = temp_doc_state_dict
    # TODO raise specific exception
    except Exception as e:
        context.log(message=str(e), obj={"tb": traceback.format_exc()})
    return data


def get_default_doc_lifecycle_data(doc_state, context,template_id,solution_id):
    """
    This function will prepare and return the default
    values of document life cycle
    :param doc_state: current doc_state of the document
    :param context: Logger Object
    :return: document life cycle default values
    """
    temp_dict = dict()
    queue_id, queue_name = get_queue_details(doc_state, context,template_id,solution_id)
    temp_dict.update({'is_assigned': False,
                      'assignee': None,
                      'assigned_ts': None,
                      'closed_ts' : None,
                      'status': 'New',
                      'queue_id': queue_id,
                      'queue_name': queue_name
                      })
    return temp_dict


def get_queue_details(doc_state, context,template_id, solution_id):
    """
    This function will scan the case_queue collection and return the
    queue_id and queue name for the given doc_state
    :param doc_state: current state of the document
    :param context: Logger Object
    :param template_id
    :param solution_id
    :return: queue_id and queue_name related to doc_state
    """
    try:
        query = {'processing_state': doc_state,
                 'document_type': template_id,
                 'solution_id': solution_id}
        projection = {'_id': 0, 'queue_id': 1, 'queue_name': 1}
        queue_data = MongoDbConn.find_one(CASE_QUEUE_COLLECTION, query,
                                          projection=projection)
        queue_id, queue_name = None, None
        if queue_data:
            if 'queue_id' in queue_data:
                queue_id = queue_data['queue_id']
            if 'queue_name' in queue_data:
                queue_name = queue_data['queue_name']
        return queue_id, queue_name
    # TODO raise specific exception
    except Exception as e:
        context.log(message=str(e), obj={"tb": traceback.format_exc()})
        return None, None

def extract_default_variable(context):
    """
    This function will return the default variables
    :param context: Logger object
    :return: default variables
    """
    try:
        doc_variables = get_variable(context)
        default_variable = []
        for ele in doc_variables:
            if ele["is_default"]:
                default_variable.append(ele)
        return default_variable
    except Exception as e:
        context.log(message=str(e), obj={"tb": traceback.format_exc()})
        return []


def get_variable(context):
    """
    This function will fetch all workflow variables
    and return the list as response
    :param logger_obj: logging object
    :return: list as response
    """
    try:
        case_variables = get_case_vars(context)
        new_case_variables = sorted(case_variables, key=lambda k: k['alias'])
        return new_case_variables
    except Exception as e:
        context.log(message=str(e), obj={"tb":traceback.format_exc()})
        return []

def get_doc_case_variable(solution_id):
    projection = {'_id': 0, 'doc_variables': 1,
                      'case_variables': 1}
    query = {'solution_id': solution_id,'is_deleted': False}
    doc_case_object_data = MongoDbConn.find_one(DOC_CASE_COLLECTION, query,
                                                    projection=projection)
    vars_list=list()
    if doc_case_object_data:
        if 'doc_variables' in doc_case_object_data:
            vars_list.extend(doc_case_object_data['doc_variables']['doc_vars'])
        if 'case_variables' in doc_case_object_data:
            vars_list.extend(doc_case_object_data['case_variables']['case_vars'])

        if len(vars_list)==0:
            res_sol_id = insert_variables(solution_id)
            return get_doc_case_variable(res_sol_id)

        return vars_list
    else:
        res_sol_id = insert_variables(solution_id)
        return get_doc_case_variable(res_sol_id)


def insert_variables(solution_id):
    with open("/home/santosh/test cases/enso-admin/case_vars.json") as case:
        case_variables=json.load(case)
    with open("/home/santosh/test cases/enso-admin/doc_vars.json") as doc:
        doc_variables=json.load(doc)
    query = {"doc_variables": doc_variables,
             "case_variables": case_variables,
             "solution_id": solution_id,
             "is_deleted": False,
             "created_ts": datetime.utcnow().isoformat(),
             "updated_ts": datetime.utcnow().isoformat()
             }
    where_query = {'solution_id': solution_id}
    MongoDbConn.update(DOC_CASE_COLLECTION, where_query, query)
    return solution_id


def fetch_case_object(request):
    """
    This function will fetch the case object from collection
    and return the dictionary as response
    :param request: Http request
    :return: dictionary as response
    """
    context = tracer.get_context(request_id=str(uuid4()), log_level="ERROR")
    context.start_span(component=__name__)
    try:
        if request.method == 'POST':
            try:
                payload = json.loads(request.body.decode())
            except:
                payload = request.POST
            if 'solution_id' in payload:
                solution_id = payload['solution_id']
            else:
                solution_id = get_solution_from_session(request)
            if 'workflow_id' not in payload:
                return {'status': 'failure',
                        'status_code': STATUS_CODES['PRECONDITION_REQUIRED'],
                        'msg': 'Workflow_id is missing in request payload.'}
            workflow_id = payload['workflow_id']
            query = {'workflow_id': int(workflow_id), 'solution_id': solution_id,
                     'is_deleted': False}
            projection = {'_id': 0, 'case_object': 1}
            wf_data_dict = MongoDbConn.find_one(WORKFLOW_COLLECTION, query,
                                                projection=projection)
            if wf_data_dict and 'case_object' in wf_data_dict:
                return {'status': 'success',
                        'msg': 'Case object fetched successfully.',
                        'data': wf_data_dict['case_object'],
                        'status_code': STATUS_CODES['OK']}
            else:
                return {'status': 'success',
                        'msg': 'Case object not available.',
                        'data': [],
                        'status_code': STATUS_CODES['NO_CONTENT']}
        return {'status': 'failure',
                'status_code': STATUS_CODES['BAD_REQUEST'],
                'msg': 'Only POST request will be accepted.'}
    except Exception as e:
        context.log(message=str(e), obj={"tb": traceback.format_exc()})
        return {'status': 'failure',
                'status_code': STATUS_CODES['INTERNAL_SERVER_ERROR'],
                'msg': 'Failed to fetch variables.'}
    finally:
        context.end_span()


def save_case_variables(request, context):
    """
    This function will save/update the case variables in workflow
    collection and return the dictionary as response
    :param request: Http request
    :param context: logger object
    :return: dictionary as response
    """
    try:
        try:
            payload = json.loads(request.body.decode())
        except:
            payload = request.POST
        if 'solution_id' in payload and payload['solution_id'].strip() \
                and payload['solution_id'].strip() != '':
            solution_id = payload['solution_id']
        else:
            solution_id = get_solution_from_session(request)
        if 'workflow_id' not in payload:
            return {'status': 'failure',
                    'status_code': STATUS_CODES['PRECONDITION_REQUIRED'],
                    'msg': 'Workflow_id is missing in request payload.'}
        workflow_id = payload['workflow_id']
        query = {'workflow_id': int(workflow_id), 'solution_id': solution_id,
                 'is_deleted': False}
        projection = {'_id': 0}
        wf_data_dict = MongoDbConn.find_one(WORKFLOW_COLLECTION, query,
                                            projection=projection)
        wf_data_dict['updated_ts'] = datetime.utcnow().isoformat()
        case_object = []
        if 'case_object' in payload:
            case_object = payload['case_object']
        if valid_case_object(case_object, context):
            wf_data_dict['case_object'] = case_object
            MongoDbConn.update(WORKFLOW_COLLECTION, query, wf_data_dict)
            return {'status': 'success', "status_code": STATUS_CODES['OK'],
                    'msg': 'case object saved successfully.'}
        else:
            return {'status': 'failure', "status_code": STATUS_CODES['NOT_ACCEPTABLE'],
                    'msg': 'Alias should be unique.'}
    except Exception as e:
        context.log(message=str(e), obj={"tb": traceback.format_exc()})
        return {'status': 'failure',
                'status_code': STATUS_CODES['INTERNAL_SERVER_ERROR'],
                'msg': 'Failed to save case variables.'}


def valid_case_object(case_objects, context):
    """
    This function will parse the case object list
    and validate it for unique alias
    and return the boolean value
    :param case_objects: List of variables
    :param context: Logger object
    :return: Boolean value
    """
    try:
        unique_alias_dict = dict()
        for case_obj in case_objects:
            if case_obj['alias'] in unique_alias_dict:
                return False
            unique_alias_dict[case_obj['alias']] = 1
        return True
    except Exception as e:
        context.log(message=str(e), obj={"tb": traceback.format_exc()})
        return False


def get_domain_obj_vars(file_path, solution_id, context):
# def get_domain_obj_vars(context):
    """
    This function will process the file exist at file_path
    and return the list of domain objects variables
    :param file_path: relative file path received from entity service
    :param context: Logger object
    :param solution_id: Session solution Id
    :return: list of domain objects variables
    """
    abs_file_path = save_file_fetched_from_efs(file_path, solution_id,
                                               context)
    # abs_file_path = '/home/xpms/Downloads/cms_7011389e-4f39-467c-a9c8-f284a704bcd6_domain_objects.json'
    if abs_file_path:
        try:
            with open(abs_file_path) as entity_domain_obj_data:
                domain_obj_data = json.load(entity_domain_obj_data)
            if 'entities' in domain_obj_data:
                return process_domain_obj_vars(domain_obj_data['entities'],
                                               context)
            else:
                return []
        except Exception as e:
            context.log(message=str(e), obj={"tb": traceback.format_exc()})
            return []
    else:
        return []


def process_domain_obj_vars(entity_data, context):
    """
    This function will process the json content
    and return the domain variables as list
    :param entity_data: json file content in json format
    :param context: Logger object
    :return: domain variables as list
    """
    try:
        domain_vars = []
        for ele in entity_data:
            if 'entity_type' not in ele:
                continue
            if ele['entity_type'] != 'domain_object':
                continue
            d_var = ele['entity_name']
            if 'attributes' in ele:
                domain_dict = {'isdefault': False,
                               'dimension': 'Domain',
                               'name': d_var,
                               'alias': d_var.replace('.', '_'),
                               'type': ele['entity_type'],
                               'variable_id': str(uuid4()),
                               'attributes': [],
                               'path_mapping': d_var}
                domain_vars.append(process_entity_vars(entity_data,
                                                       ele['attributes'],
                                                       context, d_var,
                                                       domain_dict, d_var))
            else:
                domain_vars.append({'isdefault': False,
                                    'dimension': 'Domain',
                                    'name': d_var,
                                    'alias': d_var.replace('.', '_'),
                                    'type': ele['entity_type'],
                                    'variable_id': str(uuid4()),
                                    'attributes': [],
                                    'path_mapping': d_var})
        sorted_domain_vars = sorted(domain_vars, key=lambda k: k['alias'])
        return sorted_domain_vars
    except Exception as e:
        context.log(message=str(e), obj={"tb": traceback.format_exc()})
        return []


def find_entity(key_name, entity_data):
    """
    This function will find the entity based on the entity name
    and return the entity
    :param key_name:
    :param entity_data:
    :return:
    """
    for entity in entity_data:
        if entity["entity_name"] == key_name:
            return entity
    return None


def process_entity_vars(entity_data, entity_objs, context, d_var, domain_dict, modified_var):
    """
    This function will process the entity data
    and return the list of dictionaries as response
    :param entity_data: entities data
    :param entity_objs: entity data
    :param context: logger object
    :param d_var: domain name
    :param domain_dict: domain level dictionary
    :param modified_var: modified variable string
    :return: list of dictionaries as response
    """
    try:
        for obj in entity_objs:
            if "entity_relation" in obj and "name" in obj["entity_relation"]:
                e_var = d_var
                d_var += '.' + obj['key_name']
                inner_domain_dict = {'is_default': False,
                                     'dimension': 'Domain',
                                     'name': obj['key_name'],
                                     'alias': obj['key_name'].replace('.', '_'),
                                     'type': obj['type'],
                                     'variable_id': str(uuid4()),
                                     'attributes': [],
                                     'path_mapping': d_var}
                entity = find_entity(obj['key_name'], entity_data)
                if entity and isinstance(entity, dict) and 'attributes' in entity:
                    domain_dict['attributes'].append(process_entity_vars(entity_data,
                                                                         entity['attributes'],
                                                                         context, d_var,
                                                                         inner_domain_dict, d_var))
                    d_var = e_var
                else:
                    domain_dict['attributes'].append({'is_default': False,
                                                      'dimension': 'Domain',
                                                      'name': obj['key_name'],
                                                      'alias': obj['key_name'].replace('.', '_'),
                                                      'type': obj['type'],
                                                      'variable_id': str(uuid4()),
                                                      'attributes': [],
                                                      'path_mapping': modified_var + '.' + obj['key_name']})
            else:
                domain_dict['attributes'].append({'is_default': False,
                                                  'dimension': 'Domain',
                                                  'name': obj['key_name'],
                                                  'alias': obj['key_name'].replace('.', '_'),
                                                  'type': obj['type'],
                                                  'variable_id': str(uuid4()),
                                                  'attributes': [],
                                                  'path_mapping': modified_var + '.' + obj['key_name']})
        return domain_dict
    except Exception as e:
        context.log(message=str(e), obj={"tb": traceback.format_exc()})
        return []


# def create_doc_var_json(doc_id):
def create_doc_var_json():
    """
    This function will create a json file which consists
    the document level variable
    :param doc_id: document id
    :return: file save
    """
    context = tracer.get_context(request_id=str(uuid4()), log_level="ERROR")
    context.start_span(component=__name__)
    try:
        # # doc_id = '02375897-436c-4692-b1a3-ca573674978b'
        # query = {'doc_id': doc_id}
        # projection = {'_id': 0}
        # resp = MongoDbConn.find_one(DOCUMENTS_COLLECTION, query, projection=projection)
        resp = {"processing_state":"AAA",
                "root_id":"BBB",
                "is_root":True,
                "doc_id": "DDD",
                "doc_state":"processing",
                "solution_id": "endtoend_3a7db947-0aba-4422-b86f-6d039a111f68",
                "metadata":{"properties":{"num_pages":0,
                                          "size":80435,
                                          "filename":"CCC",
                                          "extension":".pdf"},
                            "template_info":{"score":0,
                                             "name":"",
                                             "id":""}
                            },
                "children":[{}],
                "elements":[{"confidence":80,
                             "type":"section",
                             "elements":[{"score":80.0,
                                          "confidence":80.0,
                                          "label":"EEE",
                                          "type":"field",
                                          "parameters":{"label":"EEE",
                                                        "text":"VVV",
                                                        "has_label":True},
                                          "has_label":True,
                                          "text":"VVV"
                                         }],
                             "parameters":{}
                            }],
                "page_groups":[{"score":0.00121985247672529,
                                "template_id":"unknown",
                                "template_name":"unknown",
                                "start_page":1,
                                "end_page":4,
                                "template_score":0
                                }]
                }
        vars_list = list()
        for ele in resp:
            if isinstance(resp[ele], dict) or isinstance(resp[ele], list):
                if isinstance(resp[ele], dict):
                    src = [resp[ele]]
                else:
                    src = resp[ele]
                if len(src) > 0:
                    for item in src:
                        if len(item.keys()) > 0:
                            for tmp in item:
                                doc_var_dict = {'is_default': False,
                                                'dimension': 'Document',
                                                'name': tmp,
                                                'type': 'text',
                                                'variable_id': str(uuid4()),
                                                'attributes': [],
                                                'path_mapping': ele + '.' + tmp}
                                if isinstance(item[tmp], dict) or isinstance(item[tmp], list):
                                    if isinstance(item[tmp], list):
                                        for i in item[tmp]:
                                            vars_list.append(get_doc_vars(i, ele + '.' + tmp, doc_var_dict, context))
                                    else:
                                        vars_list.append(get_doc_vars(item[tmp], ele + '.' + tmp, doc_var_dict, context))
                                else:
                                    vars_list.append(doc_var_dict)
                        else:
                            vars_list.append({'is_default': False,
                                              'dimension': 'Document',
                                              'name': ele,
                                              'type': 'text',
                                              'variable_id': str(uuid4()),
                                              'attributes': [],
                                              'path_mapping': ele})
                else:
                    pass
            else:
                vars_list.append({'is_default': False,
                                'dimension': 'Document',
                                'name': ele,
                                'type': 'text',
                                'variable_id': str(uuid4()),
                                'attributes': [],
                                'path_mapping': ele})
        # doc_var_dict = get_doc_vars(resp, doc_var_dict, '', context)
        doc_var_dict = {'doc_vars': vars_list}
        with open('/tmp/doc_vars.json', 'w') as fw:
            json.dump(doc_var_dict, fw)
        fw.close()
        return {'status': 'success'}
    except Exception as e:
        context.log(message=str(e), obj={"tb": traceback.format_exc()})
    finally:
        context.end_span()


def get_doc_vars(resp_dict, path, doc_var_dict, context):
    """
    This function will parse the resp_dict and get the list of doc variables
    :param resp_dict: doc variables dictionary
    :param path: Json path
    :param doc_var_dict: document variable mapping dictionary
    :param context: logger object
    :return: doc variables list
    """
    try:
        for ele in resp_dict:
            if isinstance(resp_dict[ele], dict) or isinstance(resp_dict[ele], list):
                if isinstance(resp_dict[ele], dict):
                    src = [resp_dict[ele]]
                else:
                    src = resp_dict[ele]
                if len(src) > 0:
                    for item in src:
                        if len(item.keys()) > 0:
                            for tmp in item:
                                var_dict = {'is_default': False,
                                            'dimension': 'Document',
                                            'name': tmp,
                                            'type': 'text',
                                            'variable_id': str(uuid4()),
                                            'attributes': [],
                                            'path_mapping': path + '.' + ele + '.' + tmp}
                                if (isinstance(item[tmp], dict) and item[tmp]) or  isinstance(item[tmp], list):
                                    doc_var_dict['attributes'].append(get_doc_vars(item[tmp], path + '.' + ele, var_dict, context))
                                else:
                                    doc_var_dict['attributes'].append(var_dict)
                        else:
                            doc_var_dict['attributes'].append({'is_default': False,
                                                               'dimension': 'Document',
                                                               'name': ele,
                                                               'type': 'text',
                                                               'variable_id': str(uuid4()),
                                                               'attributes': [],
                                                               'path_mapping': path + '.' + ele})
                else:
                    pass
            else:
                doc_var_dict['attributes'].append({'is_default': False,
                                                   'dimension': 'Document',
                                                   'name': ele,
                                                   'type': 'text',
                                                   'variable_id': str(uuid4()),
                                                   'attributes': [],
                                                   'path_mapping': path + '.' + ele})
        return doc_var_dict
    except Exception as e:
        context.log(message=str(e), obj={"tb": traceback.format_exc()})
        return {}

def get_rule_id(rules_data, solution_id, context, rule_id=None):
    """
    This function will save the case queues rules at rule engine
    and return the rule_id as response
    :param rules_data: rules payload
    :param solution_id: session solution_id
    :param context: logger object
    :return: rule_id as response
    """
    try:
        resp = update_rule(solution_id, rules_data)
        if resp["status"] == "success":
            rule_id = resp["rule_id"]
        return rule_id
    except Exception as e:
        context.log(message=str(e), obj={"tb": traceback.format_exc()})
        return {'status': 'failure',
                'status_code': STATUS_CODES['INTERNAL_SERVER_ERROR'],
                'msg': 'Failed to fetch rule_id for case queue.'}


def get_names(results, key, context):
    """
    This function will fetch the existing case queue name
    and return the list of queue name as response
    :param results: All case queues for a given workflow_id
    :param key: string to be compared
    :param context: Logger object
    :return: list of queue name as response
    """
    try:
        names = []
        for ele in results:
            if key in ele:
                names.append(ele[key])
        return names
    except Exception as e:
        context.log(message=str(e), obj={"tb": traceback.format_exc()})
        return []


def delete_case_queue(payload, solution_id, context):
    """
    This function will perform the delete operation on case queue
    and return the dictionary as response
    :param payload: Http request payload
    :param solution_id: Session Solution_id
    :param context: Logger object
    :return: dictionary as response
    """
    try:
        case_queue_id = int(payload['case_queue_id'])
        query = {'case_queue_id': case_queue_id, 'solution_id': solution_id,
                 'is_deleted': False}
        projection = {'_id': 0}
        case_queue_dict = MongoDbConn.find_one(WORKFLOW_QUEUE_COLLECTION,
                                               query, projection=projection)
        if case_queue_dict and 'is_deleted' in case_queue_dict:
            case_queue_dict['is_deleted'] = True
            case_queue_dict['updated_ts'] = datetime.utcnow().isoformat()
            MongoDbConn.update(WORKFLOW_QUEUE_COLLECTION, query,
                               case_queue_dict)
            return {'status': 'success',
                    'status_code': STATUS_CODES['OK'],
                    'msg': 'Successfully deleted the case queue.'}
        return {'status': 'failure',
                'status_code': STATUS_CODES['NO_CONTENT'],
                'msg': 'Failed to delete workflow case queue.'}
    except Exception as e:
        context.log(message=str(e), obj={"tb": traceback.format_exc()})
        return {'status': 'failure',
                'status_code': STATUS_CODES['INTERNAL_SERVER_ERROR'],
                'msg': 'Failed to delete workflow case queue.'}


def fetch_case_variables(request):
    """
    This function will fetch the case level variables
    and return the dictionary as response
    :param request: Http request
    :return: dictionary as response
    """
    context = tracer.get_context(request_id=str(uuid4()), log_level="ERROR")
    context.start_span(component=__name__)
    try:
        if request.method != 'GET':
            return {'status': 'failure',
                    'status_code': STATUS_CODES['BAD_REQUEST'],
                    'msg': 'Only GET request will be accepted.'}
        return get_case_vars(context)
    except Exception as e:
        context.log(message=str(e), obj={"tb": traceback.format_exc()})
        return {'status': 'failure',
                'status_code': STATUS_CODES['INTERNAL_SERVER_ERROR'],
                'msg': 'Failed to perform CRUD operations on case queues.'}
    finally:
        context.end_span()


def get_case_vars(context):
    """
    This function will read the static json file
    and return the dictionary consist of case variables as response
    :param context: Logger object
    :return: dictionary consist of case variables as response
    """
    try:
        with open('case_vars.json') as document_vars:
            document_vars_data = json.load(document_vars)
        if 'case_vars' in document_vars_data:
            return document_vars_data['case_vars']
        else:
            return []
    except Exception as e:
        context.log(message=str(e), obj={"tb": traceback.format_exc()})
        return []


def case_management_wf_service(request):
    """
    This function will forward the request to case management
    and collect the response from  case management and return it
    :param request: Http request
    :return: response from case management
    """
    context = tracer.get_context(request_id=str(uuid4()), log_level="ERROR")
    context.start_span(component=__name__)
    try:
        full_path = request.get_full_path()
        path = '/'.join(full_path.split('/')[2:])
        method = request.method
        headers = {'authorization': request.META['HTTP_AUTHORIZATION']}
        payload = {}
        if method in ['POST', 'DELETE']:
            try:
                payload = json.loads(request.body.decode())
            except:
                payload = request.POST
        url = CASE_MANAGEMENT_SERVICE_URL + path
        if method == 'POST':
            resp = requests.post(url, data=json.dumps(payload), headers=headers)
            return json.loads(resp.text)
        if method == 'GET':
            resp = requests.get(url, headers=headers)
            return json.loads(resp.text)
        if method == 'DELETE':
            resp = requests.delete(url, data=json.dumps(payload), headers=headers)
            return json.loads(resp.text)
    except Exception as e:
        context.log(message=str(e), obj={"tb": traceback.format_exc()})
        return {'status': {'success': False,
                           'msg': 'Failed to perform CRUD operations on workflows.',
                           'code': 500}
                }
    finally:
        context.end_span()
